package com.amit.MicroServicePractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicePracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
