package com.amit.MicroServicePractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicePracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicePracticeApplication.class, args);
	}

}
