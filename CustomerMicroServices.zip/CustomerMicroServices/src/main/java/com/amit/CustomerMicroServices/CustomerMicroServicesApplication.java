package com.amit.CustomerMicroServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerMicroServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerMicroServicesApplication.class, args);
	}

}
